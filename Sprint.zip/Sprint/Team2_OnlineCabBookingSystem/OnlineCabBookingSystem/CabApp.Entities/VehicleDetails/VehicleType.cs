﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CabApp.Entities
{
    public enum VehicleType
    {
        TwoWheeler = 2,
        ThreeWheeler = 3,
        FourWheeler = 4
    }
}
